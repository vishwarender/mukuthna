const { cmd } = require('../commands');
const axios = require('axios');
const cheerio = require('cheerio');
const footer = `🎬 ALEX CINEMA 🎬`
const slogan = `POWERD BY MR-ALEX-ID`
const mvimg = `https://i.ibb.co/rcMxdWp/bb0f37bef672ee78.jpg`
const monoplease = "`"
const botimg2 = 'https://i.ibb.co/rcMxdWp/bb0f37bef672ee78.jpg'

cmd({
  pattern: "dl2",
  alias: ["dlf", "fastdl"],
  desc: "Download files from direct links. Can send to specific JID using |",
  category: "MOVIE",
  react: "📥",
  filename: __filename
}, async (conn, mek, m, { from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply }) => {

  // Split input to get URL and target JID
  const fullInput = args.join(" ");
  const [url, targetJid] = fullInput.split('|').map(str => str.trim());
  const destinationJid = targetJid || from;

  if (!url) {
      await m.react("❌");
      return reply("*Please provide a valid download link*\n\n*Usage:*\n*.dl2 [url]*\n*.dl2 [url] | [jid]*\n\n*Example:*\n*.dl2 https://example.com/file.pdf*\n*.dl2 https://example.com/file.pdf | 1234567890@g.us*");
  }

  // Validate JID if provided
  if (targetJid && !targetJid.includes('@')) {
      await m.react("❌");
      return reply("❌ Invalid JID format. Use: url | JID (e.g., https://example.com/file.pdf | 123456789@g.us)");
  }

  try {
      // Send initial processing message
      await m.react("⏳");
      await reply(`*⏳ Processing your download request...*${targetJid ? `\n*🎯 Sending to:* ${targetJid}` : ''}`);

      // Configure headers for the request
      const headers = {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
          'Accept': '*/*',
          'Accept-Encoding': 'gzip, deflate, br',
          'Connection': 'keep-alive'
      };

      // First make a HEAD request to get content type and size
      const headResponse = await axios.head(url, { headers });
      const contentType = headResponse.headers['content-type'] || 'application/octet-stream';
      const contentDisposition = headResponse.headers['content-disposition'];

      // Extract filename from content-disposition, URL, or generate one
      let fileName = '';
      if (contentDisposition) {
          const matches = /filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/.exec(contentDisposition);
          if (matches && matches[1]) {
              fileName = matches[1].replace(/['"]/g, '');
          }
      }

      // If no filename from content-disposition, try to get from URL
      if (!fileName) {
          const urlParts = url.split('/');
          fileName = urlParts[urlParts.length - 1].split('?')[0]; // Remove query parameters
          fileName = decodeURIComponent(fileName); // Decode URL-encoded characters
          fileName = fileName.replace(/[/\\?%*:|"<>]/g, '-'); // Remove invalid characters
      }

      // If still no filename, generate one
      if (!fileName || fileName === '') {
          fileName = 'downloaded_file';
      }

      // Add appropriate extension based on content type if filename doesn't have one
      if (!fileName.includes('.')) {
          const ext = getExtensionFromMimeType(contentType);
          fileName = `${fileName}.${ext}`;
      }

      // Download and send file
      await conn.sendMessage(destinationJid, {
          document: { url: url },
          fileName: fileName,
          mimetype: contentType,
          caption: `*📁 File:* ${fileName}${targetJid ? '\n*📤 Forwarded by:* ' + pushname : '\n*💫 Downloaded by:* ' + pushname}\n\n*> ${footer}`
      }, { quoted: m });

      // React to success
      await m.react("✅");

      // If sent to different JID, notify sender
      if (targetJid) {
          await reply(`*✅ File sent successfully to:* ${targetJid}`);
      }

  } catch (error) {
      console.error("Error in dl2 command:", error);
      await reply("❌ Failed to download file. Please make sure the link is valid and accessible.");
      await m.react("❌");
  }
});

// Helper function to get file extension from MIME type
function getExtensionFromMimeType(mimeType) {
  const mimeToExt = {
      'application/pdf': 'pdf',
      'application/msword': 'doc',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': 'docx',
      'application/vnd.ms-excel': 'xls',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': 'xlsx',
      'application/vnd.ms-powerpoint': 'ppt',
      'application/vnd.openxmlformats-officedocument.presentationml.presentation': 'pptx',
      'application/zip': 'zip',
      'application/x-rar-compressed': 'rar',
      'application/x-7z-compressed': '7z',
      'video/mp4': 'mp4',
      'video/x-matroska': 'mkv',
      'video/x-msvideo': 'avi',
      'audio/mpeg': 'mp3',
      'audio/wav': 'wav',
      'image/jpeg': 'jpg',
      'image/png': 'png',
      'image/gif': 'gif',
      'image/webp': 'webp',
      'text/plain': 'txt',
      'text/csv': 'csv',
      'application/json': 'json',
      'application/vnd.android.package-archive': 'apk'
  };

  return mimeToExt[mimeType] || 'bin';
}
//================================================================
cmd({
  pattern: "dl",
  alias: ["direct", "file"],
  desc: "Send any type of file directly. Can send to specific JID using |",
  category: "MOVIE",
  react: "🎥",
  filename: __filename
}, async (conn, mek, m, { from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply }) => {

  // Split input to get URL and target JID
  const fullInput = args.join(" ");
  const [url, targetJid] = fullInput.split('|').map(str => str.trim());
  const destinationJid = targetJid || from;

  if (!url) {
      await m.react("❌");
      return reply("*Please provide a direct file URL*\n\n*Usage:*\n*.dl [url]*\n*.dl [url] | [jid]*\n\n*Example:*\n*.dl https://example.com/file.pdf*\n*.dl https://example.com/file.pdf | 1234567890@g.us*");
  }

  // Validate JID if provided
  if (targetJid && !targetJid.includes('@')) {
      await m.react("❌");
      return reply("❌ Invalid JID format. Use: url | JID (e.g., https://example.com/file.pdf | 123456789@g.us)");
  }

  try {
      // Send initial processing message
      await m.react("⏳");
      await reply(`*⏳ Processing your request...*${targetJid ? `\n*🎯 Sending to:* ${targetJid}` : ''}`);

      // Detect file type from URL
      const fileType = getFileTypeFromUrl(url);
      const fileName = getFileNameFromUrl(url);

      // Download and send file
      await conn.sendMessage(destinationJid, {
          document: { url: url },
          fileName: fileName,
          mimetype: fileType,
          caption: `*📁 File :* ${fileName}${targetJid ? '\n*📤 Forwarded by:* ' + pushname : ''}\n\n> ${footer}`
      }, { quoted: m });

      // React to success
      await m.react("✅");

      // If sent to different JID, notify sender
      if (targetJid) {
          await reply(`*✅ File sent successfully to:* ${targetJid}`);
      }

  } catch (error) {
      console.error("Error in dl command:", error);
      await reply("❌ Failed to process file. Please ensure the URL is valid and accessible.");
      await m.react("❌");
  }
});

// Helper function to get file type from URL
function getFileTypeFromUrl(url) {
  const extension = url.split('.').pop().toLowerCase();
  const mimeTypes = {
      'pdf': 'application/pdf',
      'doc': 'application/msword',
      'docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'xls': 'application/vnd.ms-excel',
      'xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'ppt': 'application/vnd.ms-powerpoint',
      'pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
      'zip': 'application/zip',
      'rar': 'application/x-rar-compressed',
      '7z': 'application/x-7z-compressed',
      'mp4': 'video/mp4',
      'mkv': 'video/x-matroska',
      'avi': 'video/x-msvideo',
      'mp3': 'audio/mpeg',
      'wav': 'audio/wav',
      'jpg': 'image/jpeg',
      'jpeg': 'image/jpeg',
      'png': 'image/png',
      'gif': 'image/gif',
      'webp': 'image/webp',
      'txt': 'text/plain',
      'csv': 'text/csv',
      'json': 'application/json',
      'apk': 'application/vnd.android.package-archive'
  };
  return mimeTypes[extension] || 'application/octet-stream';
}

// Helper function to get filename from URL
function getFileNameFromUrl(url) {
  try {
      const urlParts = url.split('/');
      let fileName = urlParts[urlParts.length - 1];
      // Remove query parameters if present
      fileName = fileName.split('?')[0];
      // Decode URL-encoded characters
      fileName = decodeURIComponent(fileName);
      // Replace invalid filename characters
      fileName = fileName.replace(/[/\\?%*:|"<>]/g, '-');
      return fileName || 'downloaded_file';
  } catch (error) {
      return 'downloaded_file';
  }
}


cmd({
  pattern: "cinesub",
  alias: ["cs2", "cine"],
  desc: "Advanced Sinhala Subtitled Movie Search and Download",
  react: "🎬",
  category: "MOVIE",
  filename: __filename
}, async (conn, mek, m, { from, reply, args }) => {
  try {
      const fullInput = args.join(' ') || "latest movies";
      const [query, targetJid] = fullInput.split('|').map(str => str.trim());
      const destinationJid = targetJid || from;

      await conn.sendMessage(from, { react: { text: "🔍", key: mek.key } });

      // Base64 encoded API URL
      const apiUrlBase64 = "aHR0cHM6Ly93d3cuZGFyay15YXNpeWEtYXBpLnNpdGU=";
      const apiUrl = Buffer.from(apiUrlBase64, 'base64').toString('utf-8');

      // Create Axios instance with default config
      const api = axios.create({
          baseURL: apiUrl,
          headers: {
              'Accept': 'application/json',
              'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
          },
          timeout: 10000 // 10 seconds timeout
      });

      // Search for movies
      const searchResponse = await api.get('/private/sit1/sc1', {
          params: {
              q: query,
              apikey: 'private999apikey'
          }
      });

      const searchData = searchResponse.data;

      if (!searchData.result || !searchData.result.data.length) {
          await conn.sendMessage(from, { react: { text: "❌", key: mek.key } });
          return reply("❌ No movies found!");
      }

      let resultMessage = `*╭─「 𝐴𝐿𝐸𝑋-𝑀𝐷 」*
*╰──┈──┈──┈──┈──┈┈*
*⏤͟͟͞͞★❬❬  𝗖𝗜𝗡𝗲𝗦𝘂𝗕  〽️𝗢𝗩𝗶𝗲❭❭⏤͟͟͞͞★*\n\n`;

      searchData.result.data.forEach((movie, index) => {
          resultMessage += `*╭⃘──┈──[ ${monoplease}「${index + 1}」${monoplease} ]──┈◦•☻•◦*\n`;
          resultMessage += `*╎🎬 ➠ ${movie.title}*\n`;
          resultMessage += `*╎📆 ➠ ${movie.imdb}*\n`;
          resultMessage += `*╎🌟 ➠ ${movie.year}*\n`;
          resultMessage += `*╚─┈─┈─┈─┈─┈─┈─┈─┈─⦁⦂⦁⦂⦂⦁*\n\n`;
      });

      resultMessage += `「 🔮 𝗜𝗡𝗦𝗧𝗥𝗨𝗖𝗧𝗜𝗢𝗡𝗦 🔮 」
╭┄┄──┈┈──┈┈⦁⦂⦁⦂⦁
│☘️ 𝗥𝗲𝗽𝗹𝘆 𝗪𝗶𝘁𝗵 𝗡𝘂𝗺𝗯𝗲𝗿 (1-${searchData.result.data.length})
╰──┈─┈─┈─┈─┈─┈─┈─┈─⦁⦂⦁⦂⦁⦁

> ⏤͟͟͞͞★❮ 𝗔 𝗟 𝗘 𝗫  𝗖 𝗜 𝗡 𝗘 𝗠 𝗔 ❯⏤͟͟͞͞★`;

      const sentMessage = await conn.sendMessage(from, {
          image: { url: botimg2 },
          caption: resultMessage,
          contextInfo: {
            externalAdReply: {
                title: '𝐀  𝐋  𝐄  𝐗  -  𝐌  𝐃',
                body: '⏤͟͟͞͞★❬❬ 𝐴𝑙𝑒𝑥-𝑀𝑑 𝑊𝒉𝑎𝑡𝑠𝑎𝑝𝑝 𝐵𝑜𝑡 ❭❭⏤͟͟͞͞★',
                thumbnailUrl: botimg2,
                sourceUrl: 'https://dark-hacker-zone-log.pages.dev',
                mediaType: 1,
                renderLargerThumbnail: false
            }
          }
      }, { quoted: mek });

      const handleUserReply = async (messageUpsert) => {
          const msg = messageUpsert.messages[0];
          if (!msg.message?.extendedTextMessage) return;

          const userReply = msg.message.extendedTextMessage.text.trim();
          const messageContext = msg.message.extendedTextMessage.contextInfo;

          if (messageContext?.stanzaId === sentMessage.key.id) {
              const movieIndex = parseInt(userReply) - 1;

              if (movieIndex >= 0 && movieIndex < searchData.result.data.length) {
                  await conn.sendMessage(from, { react: { text: "⏳", key: msg.key } });

                  const movieUrl = searchData.result.data[movieIndex].link;

                  try {
                      const movieResponse = await api.get('/private/sit1/sc2', {
                          params: {
                              url: movieUrl,
                              apikey: 'private999apikey'
                          }
                      });

                      const movieData = movieResponse.data;

                      if (!movieData.status) {
                          return reply("❌ Failed to get movie details!");
                      }

                      const movie = movieData.result.data;
                      let details = `*╭─「 𝐴𝐿𝐸𝑋-𝑀𝐷 」*
*╰──┈──┈──┈──┈──┈┈*
*⏤͟͟͞͞★❬❬  〽️𝗢𝗩𝗶𝗲 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗧𝗜𝗢𝗡 ❭❭⏤͟͟͞͞★*
*╭⃘──┈──┈──┈──┈──┈◦•☻•◦*\n`;
                                            details += `*╎☘️ Tιтle* ➠ 🎬 *${movie.title}*\n`;
                                            details += `*╎📆 Rᴇʟᴇᴀꜱᴇ* ➠ ${movie.date}\n`;
                                            details += `*╎ 🌼 Rᴀᴛɪɴɢ* ➠ ${movie.imdbRate}\n`;
                                            details += `*╎〽️ Gᴇɴʀᴇs* ➠ ${movie.category.join(', ')}\n`;
                                            details += `*╎🌈 Dɪʀᴇᴄᴛᴏʀ* ➠  ${movie.director}\n`;
                                            details += `*╚─┈──┈──┈──┈───┈┈*\n\n> ⏤͟͟͞͞★❮ 𝗔 𝗟 𝗘 𝗫  𝗖 𝗜 𝗡 𝗘 𝗠 𝗔 ❯⏤͟͟͞͞★`;
                      let detailsMessage = `*╭─「 𝐴𝐿𝐸𝑋-𝑀𝐷 」*
*╰──┈──┈──┈──┈──┈┈*
*⏤͟͟͞͞★❬❬  〽️𝗢𝗩𝗶𝗲 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗧𝗜𝗢𝗡 ❭❭⏤͟͟͞͞★*
*╭⃘──┈──┈──┈──┈──┈◦•☻•◦*\n`;
                      detailsMessage += `*╎☘️ Tιтle ➠* 🎬 *${movie.title}*\n`;
                      detailsMessage += `*╎📆 Rᴇʟᴇᴀꜱᴇ ➠* ${movie.date}\n`;
                      detailsMessage += `*╎ 🌼 Rᴀᴛɪɴɢ ➠* ${movie.imdbRate}\n`;
                      detailsMessage += `*╎〽️ Gᴇɴʀᴇs ➠* ${movie.category.join(', ')}\n`;
                      detailsMessage += `*╎🌈 Dɪʀᴇᴄᴛᴏʀ ➠*  ${movie.director}\n`;
                      detailsMessage += `*╚─┈──┈──┈──┈───┈┈*\n\n`;

                      detailsMessage += `*╭┈─┈[「 ᴅᴏᴡɴʟᴏᴀᴅ ᴏᴘᴛɪᴏɴꜱ」]┈─┈⦁⦂⦁*\n`;
                      movie.dl_links.forEach((link, index) => {
                          detailsMessage += `*│ ${index + 1}. ${link.quality} | ${link.size}*\n`;
                          if (index < movie.dl_links.length - 1) {
                              
                          }
                      });
                      detailsMessage += `*╰┄─┈─┈─┈─┈─┈─┈─┈⦁⦂⦁⦂⦁⦁*\n\n`;
                      detailsMessage += `> ⏤͟͟͞͞★❮ 𝗔 𝗟 𝗘 𝗫  𝗖 𝗜 𝗡 𝗘 𝗠 𝗔 ❯⏤͟͟͞͞★\n`;

                      
                      const detailsMsg = await conn.sendMessage(from, {
                          image: { url: movie.images[0] },
                          caption: detailsMessage,
                          contextInfo: {
                            externalAdReply: {
                                title: '𝐀  𝐋  𝐄  𝐗  -  𝐌  𝐃',
                                body: '⏤͟͟͞͞★❬❬ 𝐴𝑙𝑒𝑥-𝑀𝑑 𝑊𝒉𝑎𝑡𝑠𝑎𝑝𝑝 𝐵𝑜𝑡 ❭❭⏤͟͟͞͞★',
                                thumbnailUrl: botimg2,
                                sourceUrl: 'https://dark-hacker-zone-log.pages.dev',
                                mediaType: 1,
                                renderLargerThumbnail: false
                            }
                          }
                      }, { quoted: mek });;

                      const handleQualitySelection = async (qualityMsgUpsert) => {
                          const qualityMsg = qualityMsgUpsert.messages[0];
                          if (!qualityMsg.message?.extendedTextMessage) return;

                          const qualityReply = qualityMsg.message.extendedTextMessage.text.trim();
                          const qualityContext = qualityMsg.message.extendedTextMessage.contextInfo;

                          if (qualityContext?.stanzaId === detailsMsg.key.id) {
                              const qualityIndex = parseInt(qualityReply) - 1;

                              if (qualityIndex >= 0 && qualityIndex < movie.dl_links.length) {
                                  const selectedQuality = movie.dl_links[qualityIndex];

                                  try {
                                      await conn.sendMessage(from, { react: { text: "📥", key: qualityMsg.key } });

                                      const downloadResponse = await api.get('/private/sit1/sc5', {
                                          params: {
                                              url: selectedQuality.link,
                                              apikey: 'private999apikey'
                                          }
                                      });

                                      const downloadData = downloadResponse.data;
                                      await conn.sendMessage(destinationJid, {
                                        image: { url: movie.images[0] },
                                        caption: details,
                                        contextInfo: {
                                            externalAdReply: {
                                                title: '𝐀  𝐋  𝐄  𝐗  -  𝐌  𝐃',
                                                body: '⏤͟͟͞͞★❬❬ 𝐴𝑙𝑒𝑥-𝑀𝑑 𝑊𝒉𝑎𝑡𝑠𝑎𝑝𝑝 𝐵𝑜𝑡 ❭❭⏤͟͟͞͞★',
                                                thumbnailUrl: botimg2,
                                                sourceUrl: 'https://dark-hacker-zone-log.pages.dev',
                                                mediaType: 1,
                                                renderLargerThumbnail: false
                                            }
                                        }
                                    });
                                      if (downloadData.status && downloadData.result.direct) {
                                          await conn.sendMessage(destinationJid, {
                                              document: { url: downloadData.result.direct },
                                              mimetype: "video/mp4",
                                              fileName: `${movie.title} [${selectedQuality.quality}].mp4`,
                                              caption: `🎬 *Fɪʟᴍ Nᴀᴍᴇ :* ${movie.title}
☘️ *Sɪᴢᴇ :* ${selectedQuality.size} | ${selectedQuality.quality}\n
> ⏤͟͟͞͞★❮ 𝗔 𝗟 𝗘 𝗫  𝗖 𝗜 𝗡 𝗘 𝗠 𝗔 ❯⏤͟͟͞͞★`
                                          });

                                          await conn.sendMessage(from, { react: { text: "✅", key: qualityMsg.key } });
                                      } else {
                                          throw new Error("Failed to get download link");
                                      }

                            
                                  } catch (error) {
                                      console.error(error);
                                      reply("❌ Download failed!");
                                  }
                              }
                          }
                      };

                      conn.ev.on("messages.upsert", handleQualitySelection);
                  } catch (error) {
                      console.error("Movie Details Error:", error);
                      reply("❌ Failed to fetch movie details!");
                  }
              }
          }
      };

      conn.ev.on("messages.upsert", handleUserReply);

  } catch (error) {
      console.error("Full Error:", error);
      reply(`❌ An error occurred: ${error.message}`);
  }
});
cmd({
  pattern: "movie",
  alias: ["sinhalasub", "s2"],
  desc: "Search and download Sinhala subtitled movies",
  react: "🎬",
  category: "MOVIE",
  filename: __filename
}, async (conn, mek, m, { from, reply, args }) => {
  try {
      const apiUrlBase64 = "aHR0cHM6Ly93d3cuZGFyay15YXNpeWEtYXBpLnNpdGU=";
      const apiUrl = Buffer.from(apiUrlBase64, 'base64').toString('utf-8');

      const fullInput = args.join(' ') || "deadpool";
      const [query, targetJid] = fullInput.split('|').map(str => str.trim());
      const destinationJid = targetJid || from;

      await conn.sendMessage(from, { react: { text: "🔍", key: mek.key } });

      const searchResponse = await fetch(`${apiUrl}/movie/sinhalasub/search?text=${encodeURIComponent(query)}`);
      const searchData = await searchResponse.json();

      if (!searchData.status || !searchData.result.data.length) {
          await conn.sendMessage(from, { react: { text: "❌", key: mek.key } });
          return reply("❌ No movies found!");
      }

      let resultMessage = `*╭─「 𝐴𝐿𝐸𝑋-𝑀𝐷 」*
*╰──┈──┈──┈──┈──┈┈*
*⏤͟͟͞͞★❬❬ 𝗦𝗶𝗡𝗵𝗔𝗹𝗔𝘀𝗨𝗯𝗭 𝗺𝗢𝗩𝗶𝗲 𝗶𝗡𝗳𝗢 ❭❭⏤͟͟͞͞★*\n\n`;

searchData.result.data.forEach((movie, index) => {
    resultMessage += `*╭⃘──┈──[ ${monoplease}「${index + 1}」${monoplease} ]──┈◦•☻•◦*\n`;
    resultMessage += `*╎🎬 ➠ ${movie.title}*\n`;
    resultMessage += `*╎📆 ➠ ${movie.imdb}*\n`;
    resultMessage += `*╎🌟 ➠ ${movie.year}*\n`;
    resultMessage += `*╚─┈─┈─┈─┈─┈─┈─┈─┈─⦁⦂⦁⦂⦂⦁*\n\n`;
});

resultMessage += `「 🔮 𝗜𝗡𝗦𝗧𝗥𝗨𝗖𝗧𝗜𝗢𝗡𝗦 🔮 」
╭┄┄──┈┈──┈┈⦁⦂⦁⦂⦁
│☘️ 𝗥𝗲𝗽𝗹𝘆 𝗪𝗶𝘁𝗵 𝗡𝘂𝗺𝗯𝗲𝗿 (1-${searchData.result.data.length})
╰──┈─┈─┈─┈─┈─┈─┈─┈─⦁⦂⦁⦂⦁⦁

> ⏤͟͟͞͞★❮ 𝗔 𝗟 𝗘 𝗫  𝗖 𝗜 𝗡 𝗘 𝗠 𝗔 ❯⏤͟͟͞͞★`;

      const sentMessage = await conn.sendMessage(from, {
          image: { url: botimg2 },
          caption: resultMessage,
          contextInfo: {
            externalAdReply: {
                title: '𝐀  𝐋  𝐄  𝐗  -  𝐌  𝐃',
                body: '⏤͟͟͞͞★❬❬ 𝐴𝑙𝑒𝑥-𝑀𝑑 𝑊𝒉𝑎𝑡𝑠𝑎𝑝𝑝 𝐵𝑜𝑡 ❭❭⏤͟͟͞͞★',
                thumbnailUrl: botimg2,
                sourceUrl: 'https://dark-hacker-zone-log.pages.dev',
                mediaType: 1,
                renderLargerThumbnail: false
            }
          }
      }, { quoted: mek });

      const handleUserReply = async (messageUpsert) => {
          const msg = messageUpsert.messages[0];
          if (!msg.message?.extendedTextMessage) return;

          const userReply = msg.message.extendedTextMessage.text.trim();
          const messageContext = msg.message.extendedTextMessage.contextInfo;

          if (messageContext?.stanzaId === sentMessage.key.id) {
              const movieIndex = parseInt(userReply) - 1;

              if (movieIndex >= 0 && movieIndex < searchData.result.data.length) {
                  await conn.sendMessage(from, { react: { text: "⏳", key: msg.key } });

                  const movieUrl = searchData.result.data[movieIndex].link;
                  const movieResponse = await fetch(`${apiUrl}/movie/sinhalasub/movie?url=${movieUrl}`);
                  const movieData = await movieResponse.json();

                  if (!movieData.status) {
                      return reply("❌ Failed to get movie details!");
                  }

                  const movie = movieData.result.data;

                  const pixeldrainLinks = movie.dl_links.filter(link => 
                      link.link.includes('pixeldrain.com')
                  );

                  if (pixeldrainLinks.length === 0) {
                      return reply("❌ No Pixeldrain download links available!");
                  }

                  let details = `*╭─「 𝐴𝐿𝐸𝑋-𝑀𝐷 」*
*╰──┈──┈──┈──┈──┈┈*
*⏤͟͟͞͞★❬❬  〽️𝗢𝗩𝗶𝗲 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗧𝗜𝗢𝗡 ❭❭⏤͟͟͞͞★*
*╭⃘──┈──┈──┈──┈──┈◦•☻•◦*\n`;
                                        details += `*╎☘️ Tιтle* ➠ 🎬 *${movie.title}*\n`;
                                        details += `*╎📆 Rᴇʟᴇᴀꜱᴇ* ➠ ${movie.date}\n`;
                                        details += `*╎ 🌼 Rᴀᴛɪɴɢ* ➠ ${movie.imdbRate}\n`;
                                        details += `*╎〽️ Gᴇɴʀᴇs* ➠ ${movie.category.join(', ')}\n`;
                                        details += `*╎🌈 Dɪʀᴇᴄᴛᴏʀ* ➠  ${movie.director}\n`;
                                        details += `*╚─┈──┈──┈──┈───┈┈*\n\n> ⏤͟͟͞͞★❮ 𝗔 𝗟 𝗘 𝗫  𝗖 𝗜 𝗡 𝗘 𝗠 𝗔 ❯⏤͟͟͞͞★`;
                  let detailsMessage = `*╭─「 𝐴𝐿𝐸𝑋-𝑀𝐷 」*
*╰──┈──┈──┈──┈──┈┈*
*⏤͟͟͞͞★❬❬  〽️𝗢𝗩𝗶𝗲 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗧𝗜𝗢𝗡 ❭❭⏤͟͟͞͞★*
*╭⃘──┈──┈──┈──┈──┈◦•☻•◦*\n`;
                  detailsMessage += `*╎☘️ Tιтle ➠* 🎬 *${movie.title}*\n`;
                  detailsMessage += `*╎📆 Rᴇʟᴇᴀꜱᴇ ➠* ${movie.date}\n`;
                  detailsMessage += `*╎ 🌼 Rᴀᴛɪɴɢ ➠* ${movie.imdbRate}\n`;
                  detailsMessage += `*╎〽️ Gᴇɴʀᴇs ➠* ${movie.category.join(', ')}\n`;
                  detailsMessage += `*╎🌈 Dɪʀᴇᴄᴛᴏʀ ➠*  ${movie.director}\n`;
                  detailsMessage += `*╚─┈──┈──┈──┈───┈┈*\n\n`;

                  detailsMessage += `*╭┈─┈[「 ᴅᴏᴡɴʟᴏᴀᴅ ᴏᴘᴛɪᴏɴꜱ」]┈─┈⦁⦂⦁*\n`;
                  movie.dl_links.forEach((link, index) => {
                      detailsMessage += `*│ ${index + 1}. ${link.quality} | ${link.size}*\n`;
                      if (index < movie.dl_links.length - 1) {
                          
                      }
                  });
                  detailsMessage += `*╰┄─┈─┈─┈─┈─┈─┈─┈⦁⦂⦁⦂⦁⦁*\n\n`;
                  detailsMessage += `> ⏤͟͟͞͞★❮ 𝗔 𝗟 𝗘 𝗫  𝗖 𝗜 𝗡 𝗘 𝗠 𝗔 ❯⏤͟͟͞͞★\n`;

                  const detailsMsg = await conn.sendMessage(from, {
                      image: { url: movie.images[0] },
                      caption: detailsMessage,
                      contextInfo: {
                        externalAdReply: {
                            title: '𝐀  𝐋  𝐄  𝐗  -  𝐌  𝐃',
                            body: '⏤͟͟͞͞★❬❬ 𝐴𝑙𝑒𝑥-𝑀𝑑 𝑊𝒉𝑎𝑡𝑠𝑎𝑝𝑝 𝐵𝑜𝑡 ❭❭⏤͟͟͞͞★',
                            thumbnailUrl: botimg2,
                            sourceUrl: 'https://dark-hacker-zone-log.pages.dev',
                            mediaType: 1,
                            renderLargerThumbnail: false
                        }
                      }
                  }, { quoted: mek });

                  const handleQualitySelection = async (qualityMsgUpsert) => {
                      const qualityMsg = qualityMsgUpsert.messages[0];
                      if (!qualityMsg.message?.extendedTextMessage) return;

                      const qualityReply = qualityMsg.message.extendedTextMessage.text.trim();
                      const qualityContext = qualityMsg.message.extendedTextMessage.contextInfo;

                      if (qualityContext?.stanzaId === detailsMsg.key.id) {
                          const qualityIndex = parseInt(qualityReply) - 1;

                          if (qualityIndex >= 0 && qualityIndex < pixeldrainLinks.length) {
                              const selectedQuality = pixeldrainLinks[qualityIndex];

                              try {
                                  await conn.sendMessage(from, { react: { text: "📥", key: qualityMsg.key } });

                                  const fileId = selectedQuality.link.split('/').pop();
                                  const dlResponse = await fetch(`${apiUrl}/download/pixeldrain?url=https://pixeldrain.com/api/file/${fileId}`);
                                  const dlData = await dlResponse.json();
                                  await conn.sendMessage(destinationJid, {
                                    image: { url: movie.images[0] },
                                    caption: details,
                                    contextInfo: {
                                        externalAdReply: {
                                            title: '𝐀  𝐋  𝐄  𝐗  -  𝐌  𝐃',
                                            body: '⏤͟͟͞͞★❬❬ 𝐴𝑙𝑒𝑥-𝑀𝑑 𝑊𝒉𝑎𝑡𝑠𝑎𝑝𝑝 𝐵𝑜𝑡 ❭❭⏤͟͟͞͞★',
                                            thumbnailUrl: botimg2,
                                            sourceUrl: 'https://dark-hacker-zone-log.pages.dev',
                                            mediaType: 1,
                                            renderLargerThumbnail: false
                                        }
                                    }
                                });
                                  if (dlData.status && dlData.result.dl_link) {
                                      await conn.sendMessage(destinationJid, {
                                          document: { url: dlData.result.dl_link },
                                          mimetype: "video/mp4",
                                          fileName: `${movie.title} [${selectedQuality.quality}].mp4`,
                                          caption: `🎬 *Fɪʟᴍ Nᴀᴍᴇ :* ${movie.title}
☘️ *Sɪᴢᴇ :* ${selectedQuality.size} | ${selectedQuality.quality}\n
> ⏤͟͟͞͞★❮ 𝗔 𝗟 𝗘 𝗫  𝗖 𝗜 𝗡 𝗘 𝗠 𝗔 ❯⏤͟͟͞͞★`
                                      });

                                      await conn.sendMessage(from, { react: { text: "✅", key: qualityMsg.key } });
                                  } else {
                                      throw new Error("Failed to get download link");
                                  }

                              } catch (error) {
                                  console.error(error);
                                  reply("❌ Download failed!");
                              }
                          }
                      }
                  };

                  conn.ev.on("messages.upsert", handleQualitySelection);
              }
          }
      };

      conn.ev.on("messages.upsert", handleUserReply);

  } catch (error) {
      console.error(error);
      reply("❌ An error occurred!");
  }
});
