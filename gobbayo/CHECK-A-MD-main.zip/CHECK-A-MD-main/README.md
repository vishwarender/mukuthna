***
</p> <p align="center">
<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=Rubik+Dirt&size=65&pause=1000&color=F72C3F&background=FF20A500&center=true&vCenter=true&width=1000&height=150&lines=BHASHI-MD;MADE+BY+VISHhhhhhhhhhggAM+DARK+HACK+ZONE" alt="Typing SVG" /></a>

***

<p align = center>   <img src="https://i.ibb.co/2jNJs5q/94d829c1-de36-4b7f-9d4d-f0566c361b61-1.jpg"</p>
<p align="center">

  <a href="https://github.com/vishwamihiranga/BHASHI-MD">
    <img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2Fvishwamihiranga%2FBHASHI-MD&count_bg=%2379C83D&title_bg=%23555555&icon=gitpod.svg&icon_color=%23E7E7E7&title=Views&edge_flat=false" alt="Views"/></a>
  
  </a>
  <a href="https://github.com/vishwamihiranga/BHASHI-MD/fork">
    <img src="https://img.shields.io/github/forks/vishwamihiranga/BHASHI-MD?label=Fork&style=social">
    
  </a>
  <a href="https://github.com/vishwamihiranga/BHASHI-MD/stargazers">
    <img src="https://img.shields.io/github/stars/vishwamihiranga/BHASHI-MD?style=social">
  </a>
</p>

<p align="center">
  <a href="https://github.com/vishwamihiranga/BHASHI-MD">
    <img src="https://img.shields.io/github/repo-size/vishwamihiranga/BHASHI-MD?color=purple&label=Repo%20Size&style=plastic">

  </a>
  <a href="https://github.com/vishwamihiranga/BHASHI-MD">
    <img src="https://img.shields.io/github/license/vishwamihiranga/BHASHI-MD?color=purple&label=License&style=plastic">

  </a>
  <a href="https://github.com/vishwamihiranga/BHASHI-MD">
    <img src="https://img.shields.io/github/languages/top/vishwamihiranga/BHASHI-MD?color=purple&label=Javascript&style=plastic">

  </a>
  <a href="https://github.com/vishwamihiranga/BHASHI-MD">
    <img src="https://img.shields.io/static/v1?label=Author&message=Vishwa%20Mihiranga%20And%20Bhashitha&color=purple&style=plastic">

  </a>
  </p>
 <p align="center">
  <a href="https://github.com/vishwamihiranga/BHASHI-MD">
    <img src="https://img.shields.io/badge/OUR%20%20%20TEAM-DARK%20HACK%20ZONE%20-purple&style=plastic">

  </a>
</p>
 
***


<h2 align="center">𝗖𝗢𝗡𝗡𝗘𝗖𝗧 𝗧𝗢 𝗪𝗛𝗔𝗧𝗦𝗔𝗣𝗣</h2>

<p align="center">
<a href='https://github.com/vishwamihiranga/BHASHI-MD/fork' target="_blank"><img alt='Fork Repo' src='https://img.shields.io/badge/-Fork Repo-grey?style=for-the-badge&logo=github&logoColor=white'/< width=115 height=28/p></a>

<p align="center">
<a href='https://pair-web-public.koyeb.app/' target="_blank"><img alt='Pair Code' src='https://img.shields.io/badge/-Pair Code-darkgreen?style=for-the-badge&logo=Whatsapp&logoColor=white'/< width=115 height=28/p></a>

<p align="center"> 𝗨𝗣𝗗𝗔𝗧𝗘 𝗬𝗢𝗨𝗥 𝗖𝗢𝗡𝗙𝗜𝗚.𝗝𝗦 - 𝗔𝗗𝗗 𝗦𝗘𝗦𝗦𝗜𝗢𝗡-𝗜𝗗</p>

***


<h2 align="center">𝗗𝗘𝗣𝗟𝗢𝗬𝗠𝗘𝗡𝗧 𝗠𝗘𝗧𝗛𝗢𝗗𝗦</h2>

<p align="center">
<a href='https://railway.app/new' target="_blank"><img alt='Heroku' src='https://img.shields.io/badge/-railway deploy-blue?style=for-the-badge&logo=railway&logoColor=white'/< width=150 height=28/p></a>

<p align="center">
<a href='https://signup.heroku.com/' target="_blank"><img alt='Heroku' src='https://img.shields.io/badge/-heroku ‎ deploy-blue?style=for-the-badge&logo=heroku&logoColor=white'/< width=150 height=28/p></a>

<p align="center">
<a href='https://dashboard.render.com/web/new' target="_blank"><img alt='Heroku' src='https://img.shields.io/badge/-Render deploy-blue?style=for-the-badge&logo=render&logoColor=white'/< width=150 height=28/p></a>

<p align="center">
<a href='https://app.koyeb.com/services/new?service_type=web&step=review&type=git&repository=github.com%2Fvishwamihiranga%2FBHASHI-MD&instance_type=free&regions=fra&env[SESSION_ID]=your_default_session_id&env[MONGODB]=your_default_mongodb_url&env[PREFIX]=.&env[mode]=public&env[OWNER_NUMBER]=94702481115&env[ALIVE_IMG]=your_default_alive_image_url&env[ALIVE_MSG]=I%20am%20alive!&env[AUTO_VOICE]=false&env[ANTI_BAD_WORDS_ENABLED]=true&env[AUTO_READ_STATUS]=true&env[ANTI_BAD_WORDS]=pakayo,huththo&env[ANTI_LINK]=false&env[ALWAYS_ONLINE]=false&env[ALWAYS_TYPING]=false&env[ALWAYS_RECORDING]=false&env[ANTI_BOT]=true&env[ANTI_DELETE]=true&env[packname]=🪄BHASHI&env[author]=BHASHI%20x%20VISHWA&env[OPENWEATHER_API_KEY]=2d61a72574c11c4f36173b627f8cb177&env[ELEVENLABS_API_KEY]=sk_6438bcc100d96458f8de0602aec662f4ba14b905fd090ad3&env[SHODAN_API]=cbCkidr6qd7AFVaYs56MuCouGfM8gFki&env[PEXELS_API_KEY]=39WCzaHAX939xiH22NCddGGvzp7cgbu1VVjeYUaZXyHUaWlL1LFcVFxH&env[OMDB_API_KEY]=76cb7f39&env[PIXABAY_API_KEY]=23378594-7bd620160396da6e8d2ed4d53&env[ZIPCODEBASE_API_KEY]=0f94a5f0-6ea4-11ef-81da-579be4fb031c&env[GOOGLE_API_KEY]=AIzaSyD93IeJsouK51zjKgyHAwBIAlqr-a8mnME&env[GOOGLE_CX]=AIzaSyD93IeJsouK51zjKgyHAwBIAlqr-a8mnME&env[PASTEBIN_API_KEY]=uh8QvO6vQJGtIug9WvjdTAPx_ZAFJAxn&dockerfile=./Dockerfile
' target="_blank"><img alt='Koyeb' src='https://img.shields.io/badge/-koyeb deploy-blue?style=for-the-badge&logo=koyeb&logoColor=white'/< width=150 height=28/p></a>

<p align="center">
<a href='https://app.netlify.com/' target="_blank"><img alt='Netlify' src='https://img.shields.io/badge/-Netlify Deploy-blue?style=for-the-badge&logo=netlify&logoColor=white'/< width=150 height=28/p></a> <h6>

<p align="center">
<a href='https://replit.com/~' target="_blank"><img alt='Replit' src='https://img.shields.io/badge/-Replit Deploy-blue?style=for-the-badge&logo=replit&logoColor=white'/< width=150 height=28/p></a> <h6>

<p align="center">
  <a href='https://github.com/vishwamihiranga/BHASHI-MD/blob/main/WORKFLOW.md' target="_blank">
    <img alt='Workflow' src='https://img.shields.io/badge/-WorkFlow%20Deploy-blue?style=for-the-badge&logo=github&logoColor=white' width="150" height="28"/>
  </a>



 
***

<p align="justify"> 𝗔 𝗪𝗛𝗔𝗧𝗦𝗔𝗣𝗣 𝗕𝗔𝗦𝗘𝗗 𝗧𝗛𝗜𝗥𝗗 𝗣𝗔𝗥𝗧𝗬 𝗔𝗣𝗣𝗟𝗜𝗖𝗔𝗧𝗜𝗢𝗡 𝗧𝗛𝗔𝗧 𝗣𝗥𝗢𝗩𝗜𝗗𝗘 𝗠𝗔𝗡𝗬 𝗦𝗘𝗥𝗩𝗜𝗖𝗘𝗦 𝗪𝗜𝗧𝗛 𝗔 𝗥𝗘𝗔𝗟-𝗧𝗜𝗠𝗘 𝗔𝗨𝗧𝗢𝗠𝗔𝗧𝗘𝗗 𝗖𝗢𝗡𝗩𝗘𝗥𝗦𝗔𝗧𝗜𝗢𝗡𝗔𝗟 𝗘𝗫𝗣𝗘𝗥𝗜𝗘𝗡𝗖𝗘.

<p align="justify"> 𝗕𝗛𝗔𝗦𝗛𝗜 𝗠𝗗 𝗜𝗦 𝗔𝗡 𝗨𝗦𝗘𝗥 𝗕𝗢𝗧 𝗙𝗢𝗥 𝗪𝗛𝗔𝗧𝗦𝗔𝗣𝗣 𝗧𝗛𝗔𝗧 𝗔𝗟𝗟𝗢𝗪𝗜𝗡𝗚 𝗬𝗢𝗨 𝗧𝗢 𝗚𝗘𝗧 𝗗𝗢𝗡𝗘 𝗦𝗢 𝗠𝗔𝗡𝗬 𝗧𝗔𝗦𝗞𝗦. 𝗧𝗛𝗜𝗦 𝗣𝗥𝗢𝗝𝗘𝗖𝗧 𝗠𝗔𝗜𝗡𝗟𝗬 𝗙𝗢𝗖𝗨𝗦𝗜𝗡𝗚 𝗢𝗡 𝗠𝗔𝗞𝗘 𝗨𝗦𝗘𝗥'𝗦 𝗪𝗢𝗥𝗞 𝗘𝗔𝗦𝗬. 𝗧𝗛𝗜𝗦 𝗣𝗥𝗢𝗝𝗘𝗖𝗧 𝗖𝗢𝗗𝗘𝗗 𝗪𝗜𝗧𝗛 𝗝𝗔𝗩𝗔𝗦𝗖𝗥𝗜𝗣𝗧 𝗔𝗡𝗗 𝗕𝗔𝗜𝗟𝗘𝗬𝗦 𝗔𝗦 𝗧𝗛𝗘 𝗪𝗔 𝗪𝗘𝗕 𝗔𝗣𝗜. 𝗗𝗘𝗩𝗘𝗟𝗢𝗣𝗘𝗥 𝗢𝗥 𝗧𝗘𝗔𝗠 𝗠𝗘𝗠𝗕𝗘𝗥𝗦 𝗔𝗥𝗘 𝗡𝗢𝗧 𝗥𝗘𝗦𝗣𝗢𝗡𝗦𝗜𝗕𝗟𝗘 𝗙𝗢𝗥 𝗬𝗢𝗨𝗥 𝗨𝗦𝗔𝗚𝗘 𝗠𝗜𝗦𝗧𝗔𝗞𝗘𝗦 𝗔𝗡𝗗 𝗡𝗢𝗧 𝗨𝗦𝗜𝗡𝗚 𝗪𝗜𝗦𝗘𝗟𝗬. 𝗔𝗟𝗦𝗢, 𝗬𝗢𝗨 𝗛𝗔𝗩𝗘 𝗡𝗢 𝗔𝗨𝗧𝗛𝗢𝗥𝗜𝗧𝗜𝗘𝗦 𝗗𝗢 𝗔𝗡𝗬 𝗠𝗢𝗗𝗜𝗙𝗜𝗖𝗔𝗧𝗜𝗢𝗡𝗦 𝗧𝗢 𝗧𝗛𝗜𝗦 𝗣𝗥𝗢𝗝𝗘𝗖𝗧. 𝗘𝗡𝗝𝗢𝗬 !

***

<h2 align="center">𝗥𝗘𝗠𝗜𝗡𝗗𝗘𝗥</h2>
<p style="text-align: center; font-size: 1.2em;">
  <strong>Important:</strong> This bot is not affiliated with <em>WhatsApp Inc.</em> 
  Misusing this bot may result in a <strong>ban</strong> on your WhatsApp account. 
  Please note that accounts can only be unbanned once.
</p>
<p style="text-align: center; font-size: 1.2em;">
  I am not responsible for any actions leading to the banning of your account. 
  Use at your own risk, keeping this warning in mind.
</p>

***
<h2 align="center">𝗡𝗢𝗧𝗜𝗖𝗘</h2>
<p style="text-align: center; font-size: 1.2em;">
  <strong>Not For Sale</strong><br>
  - If any plugin's code is obfuscated, you do not have permission to edit it in any form.<br>
  - Please remember to give credit if you are using or re-uploading my plugins/files.<br>
  - Wishing you a wonderful day ahead! 
</p>
    
***
<h2 align="center">𝗕𝗛𝗔𝗦𝗛𝗜 𝗠𝗗 𝗗𝗘𝗩𝗘𝗟𝗢𝗣𝗘𝗥𝗦</h2>

<div align="center">

| <a href="https://github.com/vishwamihiranga"><img src="https://i.ibb.co/DQQy17Y/image.png" width=90 height=90></a> | <a href="https://github.com/harshi2010"><img src="https://i.ibb.co/nb7Ky5d/image.png" width=90 height=90></a> | <a href="https://github.com/ALEX-ID-LK"><img src="https://i.ibb.co/2grFMBY/image.png" width=90 height=90></a> |
|---|---|---|
| **[VISHWA MIHIRANGA](https://github.com/vishwamihiranga)**</br>Founder & Developer</br> | **[BHASITHA](https://github.com/harshi2010)**</br>Owner</br> | **[ALEX-ID-LK](https://github.com/ALEX-ID-LK)**</br>Helper</br> |

</div>



